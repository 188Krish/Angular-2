import { Component } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'my-app',
    templateUrl : './src/components/app.component.html'
})
export class AppComponent{
    today: Date;
    employee: any;
    observableObj:Observable<number>;
    counter:number;
    constructor(){
        this.today = new Date();
        this.employee = {
            name: 'Karthik',
            location: {
                city: 'Bangalore',
                state: 'Karnataka'
            },
            hobbies: ['Programming','Music'],
            activeStatus: true
        }
        this.counter = 0;
        this.observableObj = Observable.interval(1000);
    }

    observe():void{
        this.observableObj.subscribe((result:number)=>{
            this.counter = result;
        });
    }
}
