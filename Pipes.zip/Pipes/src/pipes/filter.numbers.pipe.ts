import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'filterNumbers'
})
export class FilterNumbersPipe implements PipeTransform{
    transform(numbers: number[], filterType: string): number[] {
        let evenNumbers: number[] = [];
        let oddNumbers: number[] = [];
        let result :number[] = [];
        numbers.forEach(function(number){
            if(number % 2 === 0)
                evenNumbers.push(number);
            else
                oddNumbers.push(number);
        });
        if(filterType == 'even')
            return evenNumbers;
        if(filterType == 'odd')
            return oddNumbers;
        return  result;
    }
}