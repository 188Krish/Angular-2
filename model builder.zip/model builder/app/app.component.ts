import { Component,OnInit } from '@angular/core';

import { FormGroup,Validators,FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  
templateUrl: './app.component.html',
 
 styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  
userForm: FormGroup;
constructor(private _formBuilder:FormBuilder){ }
    
   
 ngOnInit(){
        this.userForm = this._formBuilder.group({
          name:['KrishnaSai',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]],
          email:[],
          address:this._formBuilder.group({
              city:[],
              postalcode:[null,[Validators.pattern('^[1-9][0-9]{4}$')]]
          })  
        })
   

}
// userForm = new FormGroup({
// name: new FormControl('KrishnaSai',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
// email: new FormControl('',Validators.required),
// address:new FormGroup({
// city: new FormControl('',Validators.required),
// postalcode: new FormControl('',Validators.pattern('^[1-9][0-9]{4}$'))
//     })
//   });
  onSubmit(){
    console.log(this.userForm.value);
  }
}
