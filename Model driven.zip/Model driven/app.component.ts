import { Component } from '@angular/core';
import { FormControl,FormGroup,Validators } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
userForm = new FormGroup({
name: new FormControl('KrishnaSai',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
email: new FormControl('',Validators.required),
address:new FormGroup({
city: new FormControl('',Validators.required),
postalcode: new FormControl('',Validators.pattern('^[1-9][0-9]{4}$'))
    })
  });
  onSubmit(){
    console.log(this.userForm.value);
  }
}
