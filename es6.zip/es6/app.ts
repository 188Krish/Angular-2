class Drone{
    id:number;
    name:string;
    constructor(id:number,name:string){
        this.id=id;
        this.name=name;
        console.log('This is my id'+ this.id+'and name' +this.name);

    }

}

let drone = new Drone(20,'saikrishna');

// console.log(typeof Drone);
// console.log(typeof drone);
// console.log(drone instanceof Drone);

