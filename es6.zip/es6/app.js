var Drone = (function () {
    function Drone(id, name) {
        this.id = id;
        this.name = name;
        console.log('This is my id' + this.id + 'and name' + this.name);
    }
    return Drone;
}());
var drone = new Drone(20, 'saikrishna');
// console.log(typeof Drone);
// console.log(typeof drone);
// console.log(drone instanceof Drone);
