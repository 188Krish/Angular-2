import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'app/employee.service';
@Component({
  selector: 'app-employee-details',
  template:`<h2>Employ-Details</h2>
            <h3>{{ errorMsg}}</h3>
            <ul *ngFor= "let employee of employees">
            <li>{{employee.id}}- {{employee.name}} from {{employee.city}}</li>
            </ul>` ,
  
})
export class EmployeeDetailsComponent implements OnInit {
 employees= [];
 errorMsg :string;
  constructor( private _employeeservice:EmployeeService){}
  ngOnInit(){
   this._employeeservice.getEmployees()
   .subscribe(
     resEmployeeData => this.employees = resEmployeeData,
   resEmployeeError => this.errorMsg = resEmployeeError);
  }
}
