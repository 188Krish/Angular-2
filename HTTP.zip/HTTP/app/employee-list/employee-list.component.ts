import { Component,OnInit} from '@angular/core';
import { EmployeeService } from 'app/employee.service';
@Component({
  selector: 'app-employee-list',
  template: `<h2>Employ-List</h2>
            <h3>{{  errorMsg}}</h3>
            <ul *ngFor= "let employee of employees">
            <li>{{employee.name}}</li>
            </ul>`,

})
export class EmployeeListComponent implements OnInit{
  employees= [];
  errorMsg :string;
  constructor( private _employeeservice:EmployeeService){}
  ngOnInit(){
   this._employeeservice.getEmployees()
   .subscribe(resEmployeeData => this.employees = resEmployeeData,
   resEmployeeError => this.errorMsg = resEmployeeError);
  }
}
