import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>This is my App</h1>
  <app-appservice></app-appservice>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
