import { Component } from '@angular/core';


@Component({
  selector: 'app-appservice',
  template:`<h2>Employ-List</h2>
            <ul *ngFor= "let employee of employees">
            <li>{{employee.name}}</li>
            </ul>`,

})
export class AppserviceComponent {

    employees=[{
  "name": "saikrishna",
  "id": "1",
  "gender": "male",
  "age": "25",
  "city": "husnabad",
  "Dist": "knr"
},
{
  "name": "krishna",
  "id": "2",
  "gender": "male",
  "age": "15",
  "city": "Knr",
  "Dist": "HZB"
},
{
  "name": "saithi",
  "id": "10",
  "gender": "female",
  "age": "5",
  "city": "koti",
  "Dist": "NZB"
}
      
    ]

}
