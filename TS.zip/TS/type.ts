let mySentence: string;
let myNumber: number;
let myBool: boolean;
let myVar:any;
// let strArr: string[];
// let numArr: number[];
// let BooArr: boolean[];
let strArr: Array<string>;
let numArr: Array<number>;
let BooArr: BooArr<boolean>;

let nuStringtuple:["number","string"]
mySentence ='This is krishna learning TypeScript'.slice(2,15);
myNumber=220;
myBool=false;
myVar=1005+'jjfjjf';
strArr=['hello','hhdh','krishna','sai'];
numArr=[1,454,44];
BooArr=[false,true,true];
nuStringtuple=[15,44,"jgjkjgjb"];
// Writing numbers and strings in afixed format
console.log(myVar);
console.log(myNumber);
console.log(mySentence);
console.log(myBool);
console.log(strArr);
console.log(numArr);
console.log(BooArr);
console.log(nuStringtuple);




