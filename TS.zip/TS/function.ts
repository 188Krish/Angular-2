function Sum(a:number,b:number):number{
    return a+b;
}
console.log(Sum(5,10));

function Fullname(firstname:string,lastname?:string):string{
    if(lastname ==undefined){
        return firstname;
    }
    return firstname +' '+lastname;
}

console.log(Fullname('Saikrishna'));

function myVoid() :void{
    return;
}
