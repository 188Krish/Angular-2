// function myWork(todo:{
//     title:string,
//     Description:string
// }){
//     console.log(todo.title+': '+todo.Description);
// }

// let Mytodo={title:'Morning work',Description:'This is my description'};
// myWork(Mytodo);

interface Todo{
     title:string,
     Description:string
}

function myWork(todo:Todo){
    console.log(todo.title+': '+todo.Description);
}

 let Mytodo={title:'Morning work',Description:'This is my description'};
 myWork(Mytodo);
