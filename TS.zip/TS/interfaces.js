// function myWork(todo:{
//     title:string,
//     Description:string
// }){
//     console.log(todo.title+': '+todo.Description);
// }
function myWork(todo) {
    console.log(todo.title + ': ' + todo.Description);
}
var Mytodo = { title: 'Morning work', Description: 'This is my description' };
myWork(Mytodo);
