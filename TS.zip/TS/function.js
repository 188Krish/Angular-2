function Sum(a, b) {
    return a + b;
}
console.log(Sum(5, 10));
function Fullname(firstname, lastname) {
    if (lastname == undefined) {
        return firstname;
    }
    return firstname + ' ' + lastname;
}
console.log(Fullname('Saikrishna'));
function myVoid() {
    return;
}
