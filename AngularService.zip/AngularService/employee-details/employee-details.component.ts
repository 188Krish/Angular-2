import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'app/employee.service';
@Component({
  selector: 'app-employee-details',
  template:`<h2>Employ-List</h2>
            <ul *ngFor= "let employee of employees">
            <li>{{employee.id}}- {{employee.name}} from {{employee.city}}</li>
            </ul>` ,
  
})
export class EmployeeDetailsComponent implements OnInit {
 employees= [];
  constructor( private _employeeservice:EmployeeService){}
  ngOnInit(){
   this.employees =this._employeeservice.getEmployees();
  }

}
