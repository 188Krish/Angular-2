import { Component,OnInit} from '@angular/core';

import { EmployeeService } from 'app/employee.service';

@Component({
  selector: 'app-employee-list',
  
template: `<h2>Employ-List</h2>
     
       <ul *ngFor= "let employee of employees">
           
 <li>{{employee.name}}</li>
            </ul>`,

})

export class EmployeeListComponent implements OnInit{
  
employees= [];
  constructor( private _employeeservice:EmployeeService){}

  ngOnInit(){
   this.employees =this._employeeservice.getEmployees();
  }
}
