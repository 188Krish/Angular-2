import {Injectable} from '@angular/core';
@Injectable()
export class EmployeeService{
  getEmployees(){
    return  [{
      "name": "saikrishna",
      "id": "1",
      "gender": "male",
      "age": "25",
      "city": "husnabad",
      "Dist": "knr"
    },
      {
        "name": "krishna",
        "id": "2",
        "gender": "male",
        "age": "15",
        "city": "Knr",
        "Dist": "HZB"
      },
      {
        "name": "saithi",
        "id": "3",
        "gender": "female",
        "age": "5",
        "city": "koti",
        "Dist": "NZB"
      }

    ]
  }
}
