
import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { DepartmentDetailsComponent } from './department-details/department-details.component';
import { DepartmentinDetailComponent } from './departmentin-detail/departmentin-detail.component';

const routes:Routes =[
    {path:'Employers',component:EmployeeDetailsComponent},
    {path:'Department',component:DepartmentDetailsComponent},
    {path:'Departmentindetail/:id',component:DepartmentinDetailComponent}
];

@NgModule({
  
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
      RouterModule
  ]
})

export class AppRoutingModule{}
export const routingComponents =[DepartmentDetailsComponent,EmployeeDetailsComponent,DepartmentinDetailComponent]