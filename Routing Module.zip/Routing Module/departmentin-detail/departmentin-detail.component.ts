import { Component} from '@angular/core';

@Component({
  
  template:`<h3>You have selected with an id of</h3>` ,
  
})
export class DepartmentinDetailComponent {

  

}
