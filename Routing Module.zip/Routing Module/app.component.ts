import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>My Routing Application</h1>
            <nav>
            <a routerLink="Department" routerLinkActive="active">Departments</a>
            <a routerLink="Employers" routerLinkActive="active">Employees</a>
            </nav>
            <router-outlet></router-outlet>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {

}
