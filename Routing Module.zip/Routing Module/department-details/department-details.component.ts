import { Component} from '@angular/core';
import{ Router } from '@angular/router';
@Component({
  selector: 'app-department-details',
  template: `<h2>Department List</h2>
             <ul class="items"> 
             <li (click)="onSelect(department)"*ngFor="let department of departments"><span class="badge">{{department.id}}</span> {{department.name}}</li>
             </ul>`,
  
})
export class DepartmentDetailsComponent {
  constructor(private router :Router){}
departments=[
    {"id":1,"name":"Angular"},
    {"id":2,"name":"Angular2"},
    {"id":3,"name":"Node"},
    {"id":4,"name":"Polymer"},
    {"id":5,"name":"React"},
]
  
  onSelect(department){
    this.router.navigate(['/Department',department.id]);
  }
}
