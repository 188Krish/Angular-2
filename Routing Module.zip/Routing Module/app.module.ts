import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import {AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import{routingComponents}from './app-routing.module';
import { DepartmentinDetailComponent } from './departmentin-detail/departmentin-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    DepartmentinDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
