import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
    selector: '[cg-hover]'
})
export class CgHoverDirective{
   @HostBinding('title') titleProperty:string;

   @HostListener('mouseover',['$event.target'])
   OnMouseOver(element:HTMLInputElement):void{
       let style = element.attributes.getNamedItem('cg-hover').value;
       this.titleProperty = `Mouse Over the Button and the style ${style} applied`;
       element.classList.add(style);
   }

    @HostListener('mouseleave',['$event.target'])
   OnMouseLeave(element:HTMLInputElement):void{
       let style = element.attributes.getNamedItem('cg-hover').value;
       this.titleProperty = `Mouse pointer left the Button and the style ${style} removed`;
       element.classList.remove(style);
   }
  

}