import { Component } from '@angular/core';
import { Employee } from '../models/employee';

@Component({
    selector: 'my-app',
    templateUrl : './src/components/app.component.html',
    styles: [
        '.isOn { background-color: crimson }',
        '.style01 {background-color: yellow; color: black}',
        '.style02 {background-color: red; color: white}'
    ]
})
export class AppComponent{
    status: boolean;
    cities: string[];
    employees: Employee[];
    counter: number;
    onStatus: boolean;
    style: string;
    weight: string;
    size: string;
    message: string;

    constructor(){
        this.status = true;
        this.cities = ['Bangalore','Chennai','Hyderabad','Mumbai','Pune'];
        this.employees = [
            {id:1, name:'Arvind'},
            {id:2, name:'Ashwin'},
            {id:3, name:'Abishek'},            
        ];
        this.counter = 0;
        this.onStatus = false;
        this.style = 'normal';
        this.weight = 'normal';
        this.size = '20px';
        this.message = 'Initial Message';
    }

    changeDisplay():void{
        this.status = !this.status;
    }

    incrementCounter():void{
        this.counter++;
    }
    changeWeight():void{
        this.weight = this.weight == 'bold'?'normal':'bold';
    }
    changeStyle(event: Event):void{
        this.style = (event.target as HTMLInputElement).checked === true ?'italic':'normal';
    }
    
}
